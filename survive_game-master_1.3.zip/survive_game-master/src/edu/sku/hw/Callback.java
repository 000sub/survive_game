package edu.sku.hw;

public interface Callback {
	public void callbackClick(Item item);
	public void callbackTimeOver();
}
