package edu.sku.hw;

public class Constant {
	public static int game_width   	= 1300;
	public static int game_height  	= 730;
	public static int ppt_width    	= 25;
	public static int ppt_height	= 15;
	public static int timer_max 	= 60;
	
	public static boolean isDebug	= true;	
}